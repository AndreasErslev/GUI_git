<template>
    <div class="CreateManager">
        <h1>This is an model page</h1>
    </div>
</template>
