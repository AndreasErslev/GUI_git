<template>
    <div class="CreateManager">
        <h1>This is an manager page</h1>
    </div>
</template>
