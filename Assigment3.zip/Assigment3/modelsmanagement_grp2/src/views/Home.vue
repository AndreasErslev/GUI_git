<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png" class="logo"/>
  </div>
    <p class="standardText">Welcome to the model management system</p>
</template>

<script>
    
</script>

<style>
    .logo{
        width: 40%
    }
    .standardText
    {
        font-size: 18px;
    }
</style>
